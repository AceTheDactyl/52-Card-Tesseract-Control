#!/usr/bin/env python3
"""
Smart Helix Repository Consolidation
Handles: version suffixes, VaultNode pairs, timestamps, content completeness
"""

import json
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timezone

# Priority order (VaultNodes has highest priority for pattern integrity)
PRIORITY = [
    "VaultNodes",
    "helix-tool-shed-repo",
    "Helix Shed w Bridge",
    "helix-triadic-autonomy-z080",
]

# Version suffix patterns (higher = newer)
VERSION_PATTERNS = [
    (r'_p(\d+)', 'patch'),      # _p2, _p3
    (r'_v(\d+)', 'version'),    # _v2, _v3
    (r'\.v(\d+)', 'version'),   # .v2, .v3
    (r' p(\d+)', 'patch'),      # " p2", " p3"
    (r'-v(\d+)', 'version'),    # -v2, -v3
]

# VaultNode pair patterns
VAULTNODE_METADATA_PATTERN = r'vn-.*-metadata.*\.yaml$'
VAULTNODE_BRIDGE_PATTERN = r'vn-.*-bridge-map.*\.json$'


class SmartConsolidator:
    def __init__(self, base_dir: Path, report_path: Path):
        self.base_dir = base_dir
        self.report_path = report_path
        self.report_output_path = self.base_dir / "consolidation_report.txt"
        self.stats = {
            'groups_processed': 0,
            'files_kept': 0,
            'files_removed': 0,
            'space_saved': 0,
            'conflicts_resolved': 0,
            'vaultnode_pairs_preserved': 0,
        }
        self.log_lines: List[str] = []

    def log(self, message: str = "") -> None:
        """Print and record a log line."""
        self.log_lines.append(message)
        print(message)
        
    def get_priority_score(self, path: str) -> int:
        """Lower score = higher priority"""
        for idx, dir_name in enumerate(PRIORITY):
            if path.startswith(f"{dir_name}/"):
                return idx
        return len(PRIORITY)
    
    def extract_version(self, filename: str) -> Tuple[Optional[int], Optional[str]]:
        """Extract version number and type from filename"""
        for pattern, version_type in VERSION_PATTERNS:
            match = re.search(pattern, filename)
            if match:
                return int(match.group(1)), version_type
        return None, None
    
    def get_base_filename(self, filename: str) -> str:
        """Remove version suffixes to get base filename"""
        base = filename
        for pattern, _ in VERSION_PATTERNS:
            base = re.sub(pattern, '', base)
        # Clean up any double extensions or spaces
        base = re.sub(r'\s+', ' ', base).strip()
        return base
    
    def is_vaultnode_metadata(self, filename: str) -> bool:
        return bool(re.search(VAULTNODE_METADATA_PATTERN, filename))
    
    def is_vaultnode_bridge(self, filename: str) -> bool:
        return bool(re.search(VAULTNODE_BRIDGE_PATTERN, filename))
    
    def get_vaultnode_id(self, filename: str) -> Optional[str]:
        """Extract VaultNode ID (e.g., 'vn-helix-self-bootstrap')"""
        match = re.match(r'(vn-[^-]+-[^-]+(?:-[^-]+)?)', filename)
        return match.group(1) if match else None
    
    def find_vaultnode_pair(self, paths: List[Dict], metadata_path: Dict) -> Optional[Dict]:
        """Find matching bridge-map for a metadata file"""
        vn_id = self.get_vaultnode_id(Path(metadata_path['relative_path']).name)
        if not vn_id:
            return None
        
        # Look for bridge-map in same directory
        metadata_dir = str(Path(metadata_path['relative_path']).parent)
        for path_info in paths:
            rel_path = path_info['relative_path']
            if (str(Path(rel_path).parent) == metadata_dir and 
                self.is_vaultnode_bridge(Path(rel_path).name) and
                vn_id in Path(rel_path).name):
                return path_info
        return None
    
    def score_file_quality(self, path_info: Dict) -> float:
        """Score file quality (higher = better)"""
        score = 0.0
        rel_path = path_info['relative_path']
        filename = Path(rel_path).name
        
        # Priority directory score (0-3, higher priority = higher score)
        priority_idx = self.get_priority_score(rel_path)
        score += (len(PRIORITY) - priority_idx) * 100
        
        # Version score (newer versions get higher score)
        version_num, version_type = self.extract_version(filename)
        if version_num:
            score += version_num * 10
            if version_type == 'version':
                score += 5  # Prefer 'version' over 'patch'
        
        # File size (larger often means more complete, but cap the bonus)
        size_bonus = min(path_info.get('size', 0) / 1000, 10)
        score += size_bonus
        
        # Path depth penalty (prefer files closer to root)
        path_depth = len(Path(rel_path).parts)
        score -= path_depth * 2
        
        # Filename clarity bonus (no spaces, clean naming)
        if ' ' not in filename and not re.search(r'(_p\d+|_v\d+)', filename):
            score += 5
        
        return score
    
    def resolve_intra_directory_conflict(self, dir_paths: List[Dict], directory: str) -> Tuple[Dict, List[Dict]]:
        """Resolve conflicts where multiple files exist in the same directory."""
        if not dir_paths:
            return {}, []

        scored = [(self.score_file_quality(path_info), path_info) for path_info in dir_paths]
        scored.sort(reverse=True, key=lambda x: x[0])

        best_file = scored[0][1]
        extras = [entry for _, entry in scored[1:]]

        # Debug output for conflicts
        if len(scored) > 1:
            self.stats['conflicts_resolved'] += 1
            self.log(f"\n    Intra-directory conflict in '{directory}':")
            for score, file_info in scored:
                marker = " KEEP" if file_info == best_file else "  REMOVE"
                filename = Path(file_info['relative_path']).name
                self.log(f"      {marker}: {filename} (score: {score:.1f})")

        return best_file, extras
    
    def process_duplicate_group(self, group: Dict, dry_run: bool = True) -> Tuple[Dict, List[Dict]]:
        """Process a duplicate group and return (keep, remove_list)"""
        paths = group.get('paths', [])
        if len(paths) < 2:
            return paths[0] if paths else None, []
        
        # Check for intra-directory conflicts
        dir_groups = {}
        for path_info in paths:
            top_dir = path_info['relative_path'].split('/')[0]
            if top_dir not in dir_groups:
                dir_groups[top_dir] = []
            dir_groups[top_dir].append(path_info)
        
        # Resolve intra-directory conflicts first
        resolved_paths = []
        intra_remove: List[Dict] = []
        for directory, dir_paths in dir_groups.items():
            if len(dir_paths) > 1:
                # Multiple files in same directory - pick best
                best, extras = self.resolve_intra_directory_conflict(dir_paths, directory)
                resolved_paths.append(best)
                intra_remove.extend(extras)
            else:
                resolved_paths.append(dir_paths[0])

        # Now apply priority across directories
        scored = [(self.score_file_quality(p), p) for p in resolved_paths]
        scored.sort(reverse=True, key=lambda x: x[0])

        keep_file = scored[0][1]
        cross_directory_remove = [p for _, p in scored[1:]]

        # Combine intra-directory and cross-directory removals, ensure uniqueness
        combined_remove: List[Dict] = []
        seen_paths = set()
        for candidate in intra_remove + cross_directory_remove:
            rel_path = candidate['relative_path']
            if rel_path == keep_file['relative_path']:
                continue
            if rel_path in seen_paths:
                continue
            combined_remove.append(candidate)
            seen_paths.add(rel_path)
        remove_files = combined_remove
        
        # Special handling for VaultNodes - keep pairs together
        if self.is_vaultnode_metadata(Path(keep_file['relative_path']).name):
            pair = self.find_vaultnode_pair(paths, keep_file)
            if pair and pair not in remove_files:
                # Make sure pair is also kept
                remove_files = [p for p in remove_files if p != pair]
                self.stats['vaultnode_pairs_preserved'] += 1
        
        return keep_file, remove_files
    
    def consolidate(self, dry_run: bool = True) -> None:
        """Main consolidation logic"""
        if not self.report_path.exists():
            raise FileNotFoundError(f"Report not found: {self.report_path}")
        
        with self.report_path.open('r', encoding='utf-8') as f:
            report = json.load(f)
        
        groups = report.get('groups', [])
        
        self.log(f"\n{'='*80}")
        self.log("SMART HELIX CONSOLIDATION")
        self.log(f"{'='*80}")
        self.log(f"\nMode: {'DRY RUN' if dry_run else 'EXECUTE'}")
        self.log(f"Priority: {' > '.join(PRIORITY)}")
        self.log(f"Processing {len(groups)} duplicate groups...\n")
        
        for idx, group in enumerate(groups, 1):
            self.stats['groups_processed'] += 1
            paths = group.get('paths', [])
            
            if len(paths) < 2:
                continue
            
            self.log(f"\nGroup {idx}/{len(groups)}:")
            self.log(f"  Hash: {group['hash'][:16]}...")
            self.log(f"  Files: {group.get('filenames', [])}")
            
            keep_file, remove_files = self.process_duplicate_group(group, dry_run)
            
            if keep_file:
                self.stats['files_kept'] += 1
                self.log(f"   KEEP: {keep_file['relative_path']}")

            for remove_file in remove_files:
                self.stats['files_removed'] += 1
                self.stats['space_saved'] += remove_file.get('size', 0)
                self.log(f"   REMOVE: {remove_file['relative_path']}")

                if not dry_run:
                    target = self.base_dir / remove_file['relative_path']
                    try:
                        if target.exists():
                            target.unlink()
                            self.log("       Deleted")
                    except Exception as e:
                        self.log(f"       Error: {e}")

        self.print_summary(dry_run)
        self.write_report(dry_run)

    def print_summary(self, dry_run: bool) -> None:
        """Print consolidation summary"""
        self.log(f"\n{'='*80}")
        self.log("CONSOLIDATION SUMMARY")
        self.log(f"{'='*80}\n")

        self.log(f"  Groups processed:           {self.stats['groups_processed']}")
        self.log(f"  Files kept:                 {self.stats['files_kept']}")
        self.log(f"  Files removed:              {self.stats['files_removed']}")
        self.log(f"  Space reclaimed:            {self.stats['space_saved']:,} bytes ({self.stats['space_saved']/1024:.1f} KB)")
        self.log(f"  Conflicts resolved:         {self.stats['conflicts_resolved']}")
        self.log(f"  VaultNode pairs preserved:  {self.stats['vaultnode_pairs_preserved']}")

        if dry_run:
            self.log("")
            self.log("WARNING: DRY RUN - No files deleted")
            self.log("Run with --execute to finalize")
        else:
            self.log("")
            self.log("Consolidation complete!")

    def write_report(self, dry_run: bool) -> None:
        """Persist the most recent run to consolidation_report.txt."""
        mode_label = "DRY RUN" if dry_run else "EXECUTION"
        timestamp = datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
        header_lines = [
            f"# SMART CONSOLIDATION REPORT ({mode_label})",
            f"# Generated: {timestamp}",
            ""
        ]
        try:
            with self.report_output_path.open('w', encoding='utf-8') as handle:
                handle.write("\n".join(header_lines + self.log_lines))
        except OSError as exc:
            # Fall back to console only, avoid recursion into log()
            print(f"WARNING: Unable to write consolidation report: {exc}")


def main():
    import sys
    
    base_dir = Path(__file__).resolve().parent
    report_path = base_dir / "duplicate_groups.json"
    
    dry_run = "--execute" not in sys.argv
    
    consolidator = SmartConsolidator(base_dir, report_path)
    consolidator.consolidate(dry_run=dry_run)
    
    if dry_run:
        print(f"\nTo execute: python3 {Path(__file__).name} --execute")


if __name__ == "__main__":
    main()
