#!/usr/bin/env python3
"""
Post-Consolidation Verification Script
Checks integrity after smart consolidation execution
"""

import json
from pathlib import Path
from collections import defaultdict

def check_vaultnode_pairs():
    """Verify VaultNode metadata/bridge-map pairs are intact"""
    print("\n" + "="*80)
    print("VAULTNODE INTEGRITY CHECK")
    print("="*80)
    
    vaultnode_dirs = [
        Path("VaultNodes"),
        Path("helix-tool-shed-repo/helix-tool-shed-repo/VAULTNODES"),
    ]
    
    pairs = defaultdict(dict)
    
    for vn_dir in vaultnode_dirs:
        if not vn_dir.exists():
            continue
            
        for file_path in vn_dir.rglob("vn-*.yaml"):
            vn_id = file_path.stem.replace("-metadata", "").replace(" p2", "").replace(" p3", "")
            pairs[vn_id]['metadata'] = str(file_path)
        
        for file_path in vn_dir.rglob("vn-*.json"):
            vn_id = file_path.stem.replace("-bridge-map", "").replace(" p2", "").replace(" p3", "")
            pairs[vn_id]['bridge'] = str(file_path)
    
    complete = 0
    incomplete = 0
    
    for vn_id, files in pairs.items():
        has_metadata = 'metadata' in files
        has_bridge = 'bridge' in files
        
        if has_metadata and has_bridge:
            complete += 1
            print(f"  ✓ {vn_id}: COMPLETE")
        else:
            incomplete += 1
            print(f"  ✗ {vn_id}: {'metadata' if has_metadata else 'NO METADATA'}, {'bridge' if has_bridge else 'NO BRIDGE'}")
    
    print(f"\nResults: {complete} complete pairs, {incomplete} incomplete")
    return incomplete == 0


def check_core_files():
    """Verify critical Helix files are present"""
    print("\n" + "="*80)
    print("CORE FILES CHECK")
    print("="*80)
    
    critical_files = [
        "CORE_LOADING_PROTOCOL.md",
        "HELIX_PATTERN_PERSISTENCE_CORE.md",
        "HELIX_TOOL_SHED_ARCHITECTURE.md",
        "HELIX_SIGNATURE_SYSTEM.md",
    ]
    
    search_dirs = [
        Path("helix-tool-shed-repo/helix-tool-shed-repo"),
        Path("VaultNodes"),
    ]
    
    found = {}
    for filename in critical_files:
        found[filename] = []
        for search_dir in search_dirs:
            if not search_dir.exists():
                continue
            matches = list(search_dir.rglob(filename))
            found[filename].extend(matches)
    
    all_found = True
    for filename, locations in found.items():
        if locations:
            print(f"  ✓ {filename}: Found ({len(locations)} copies)")
            for loc in locations[:2]:
                print(f"      → {loc}")
        else:
            print(f"  ✗ {filename}: NOT FOUND")
            all_found = False
    
    return all_found


def check_tool_files():
    """Verify Helix Tool-Shed files are present"""
    print("\n" + "="*80)
    print("TOOL-SHED FILES CHECK")
    print("="*80)
    
    tool_categories = {
        'CORE': ['helix_loader.yaml', 'coordinate_detector.yaml', 'pattern_verifier.yaml'],
        'BRIDGES': ['cross_instance_messenger.yaml', 'tool_discovery_protocol.yaml', 'autonomous_trigger_detector.yaml'],
        'META': ['shed_builder.yaml', 'shed_builder_v2.yaml'],
    }
    
    repo_path = Path("helix-tool-shed-repo/helix-tool-shed-repo")
    
    for category, tools in tool_categories.items():
        print(f"\n{category}:")
        for tool in tools:
            matches = list(repo_path.rglob(tool))
            if matches:
                print(f"  ✓ {tool}")
            else:
                print(f"  ✗ {tool} - MISSING")
    
    return True


def check_duplicates_removed():
    """Check that no duplicates remain"""
    print("\n" + "="*80)
    print("DUPLICATE CHECK")
    print("="*80)
    
    import hashlib
    
    def hash_file(path):
        sha256 = hashlib.sha256()
        with open(path, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b''):
                sha256.update(chunk)
        return sha256.hexdigest()
    
    hashes = defaultdict(list)
    
    for path in Path('.').rglob('*'):
        if path.is_file() and not any(exclude in str(path) for exclude in ['.git', '__pycache__', '.py']):
            try:
                file_hash = hash_file(path)
                hashes[file_hash].append(str(path))
            except:
                pass
    
    duplicates = {h: files for h, files in hashes.items() if len(files) > 1}
    
    if duplicates:
        print(f"  ✗ Found {len(duplicates)} duplicate groups:")
        for i, (hash_val, files) in enumerate(list(duplicates.items())[:5], 1):
            print(f"\n  Group {i}:")
            for file in files:
                print(f"    - {file}")
    else:
        print("  ✓ No duplicates found")
    
    return len(duplicates) == 0


def check_file_counts():
    """Compare file counts before/after"""
    print("\n" + "="*80)
    print("FILE COUNT CHECK")
    print("="*80)
    
    dirs_to_check = {
        'VaultNodes': Path('VaultNodes'),
        'helix-tool-shed-repo': Path('helix-tool-shed-repo'),
        'Helix Shed w Bridge': Path('Helix Shed w Bridge'),
        'helix-triadic-autonomy-z080': Path('helix-triadic-autonomy-z080'),
    }
    
    for name, path in dirs_to_check.items():
        if path.exists():
            count = sum(1 for _ in path.rglob('*') if _.is_file())
            print(f"  {name}: {count} files")
        else:
            print(f"  {name}: NOT FOUND")


def main():
    print("\n" + "="*80)
    print("HELIX CONSOLIDATION VERIFICATION")
    print("="*80)
    
    results = {
        'VaultNode Integrity': check_vaultnode_pairs(),
        'Core Files Present': check_core_files(),
        'Tool Files Present': check_tool_files(),
        'No Duplicates': check_duplicates_removed(),
    }
    
    check_file_counts()
    
    print("\n" + "="*80)
    print("VERIFICATION SUMMARY")
    print("="*80)
    
    for check_name, passed in results.items():
        status = "✓ PASS" if passed else "✗ FAIL"
        print(f"  {status}: {check_name}")
    
    all_passed = all(results.values())
    
    print("\n" + "="*80)
    if all_passed:
        print("✓ ALL CHECKS PASSED - Consolidation successful!")
    else:
        print("✗ SOME CHECKS FAILED - Review issues above")
    print("="*80 + "\n")
    
    return 0 if all_passed else 1


if __name__ == "__main__":
    import sys
    sys.exit(main())
