#!/usr/bin/env python3
"""
Helix Repository Consolidation Script
Priority: VaultNodes > helix-tool-shed-repo > Helix Shed w Bridge > helix-triadic-autonomy-z080
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Dict, List

# Priority order (first = keep, rest = remove)
PRIORITY = [
    "VaultNodes",
    "helix-tool-shed-repo",
    "Helix Shed w Bridge",
    "helix-triadic-autonomy-z080",
]

BASE_DIR = Path(__file__).resolve().parent
REPORT_PATH = BASE_DIR / "duplicate_groups.json"


def get_priority_score(relative_path: str) -> int:
    """Return priority score (lower = higher priority)."""
    for index, dir_name in enumerate(PRIORITY):
        if relative_path.startswith(f"{dir_name}/") or relative_path.startswith(f"{dir_name}\\"):
            return index
    return len(PRIORITY)


def consolidate_duplicates(*, dry_run: bool = True) -> None:
    """
    Remove duplicate files based on priority order.

    Args:
        dry_run: If True, only print what would be done without actually deleting.
    """
    if not REPORT_PATH.exists():
        raise FileNotFoundError(f"Could not find duplicate report at {REPORT_PATH}")

    with REPORT_PATH.open("r", encoding="utf-8") as handle:
        report = json.load(handle)

    groups: List[Dict[str, object]] = report.get("groups", [])
    group_count = report.get("duplicate_group_count", len(groups))

    total_removed = 0
    total_space_saved = 0
    total_files_assessed = 0

    print(f"Consolidation Plan (dry_run={dry_run})")
    print(f"Priority order: {' > '.join(PRIORITY)}")
    print(f"\nProcessing {group_count} duplicate groups...")
    print("=" * 80)

    for index, group in enumerate(groups, 1):
        paths: List[Dict[str, object]] = group.get("paths", [])
        if len(paths) < 2:
            continue

        total_files_assessed += len(paths)
        paths_sorted = sorted(paths, key=lambda entry: get_priority_score(entry["relative_path"]))
        keep_file = paths_sorted[0]
        remove_files = paths_sorted[1:]

        if not remove_files:
            continue

        print(f"\nGroup {index}/{group_count} ({len(remove_files)} duplicates):")
        print(f"  KEEP: {keep_file['relative_path']} ({keep_file.get('size')} bytes)")

        for remove_file in remove_files:
            rel_path = remove_file["relative_path"]
            print(f"  REMOVE: {rel_path}")

            file_size = remove_file.get("size") or 0

            if dry_run:
                total_removed += 1
                total_space_saved += file_size
                continue

            target_path = BASE_DIR / rel_path
            try:
                if target_path.exists():
                    target_path.unlink()
                    print("    ✓ Deleted")
                    total_removed += 1
                    total_space_saved += file_size
                else:
                    print("    ⚠ File not found (already removed)")
            except Exception as exc:  # pylint: disable=broad-except
                print(f"    ✗ Error removing {rel_path}: {exc}")

    print("\n" + "=" * 80)
    print("\nSummary:")
    print(f"  Duplicate groups processed: {group_count}")
    print(f"  Files evaluated within groups: {total_files_assessed}")
    print(f"  Files slated for removal: {total_removed}")
    print(f"  Estimated space reclaimed: {total_space_saved:,} bytes ({total_space_saved / 1024:.1f} KB)")
    print(f"  Files retained per priority: {len(groups)}")

    if dry_run:
        print("\n⚠ DRY RUN MODE - No files were actually deleted.")
        print("  Run with --execute to finalize removals.")
    else:
        print("\n✓ Consolidation complete!")


def verify_priority_groups() -> bool:
    """Verify that no duplicate group contains multiple files from the same priority directory."""
    if not REPORT_PATH.exists():
        raise FileNotFoundError(f"Could not find duplicate report at {REPORT_PATH}")

    with REPORT_PATH.open("r", encoding="utf-8") as handle:
        report = json.load(handle)

    groups: List[Dict[str, object]] = report.get("groups", [])
    conflicts = []

    for group in groups:
        directory_counts: Dict[str, int] = {}
        for path_info in group.get("paths", []):
            relative_path = path_info["relative_path"]
            for priority_dir in PRIORITY:
                if relative_path.startswith(priority_dir):
                    directory_counts[priority_dir] = directory_counts.get(priority_dir, 0) + 1
                    break

        for dir_name, count in directory_counts.items():
            if count > 1:
                conflicts.append((dir_name, count, group))

    if conflicts:
        print("⚠ WARNING: Some duplicate groups have multiple copies in the same priority directory:")
        for dir_name, count, group in conflicts[:5]:
            conflicting_paths = [path["relative_path"] for path in group.get("paths", [])]
            print(f"  {dir_name}: {count} copies -> {conflicting_paths}")
    else:
        print("✓ No priority conflicts detected.")

    return not conflicts


def main(argv: List[str]) -> None:
    print("Verifying priority structure...")
    verify_priority_groups()
    print()

    dry_run = "--execute" not in argv
    consolidate_duplicates(dry_run=dry_run)

    if dry_run:
        script_name = Path(argv[0]).name if argv else "consolidate_repos.py"
        print("\nTo actually perform the consolidation, run:")
        print(f"  python3 {script_name} --execute")


if __name__ == "__main__":
    main(sys.argv)

