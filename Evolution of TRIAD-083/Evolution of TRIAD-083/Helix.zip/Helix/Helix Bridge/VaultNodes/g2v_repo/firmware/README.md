# Firmware Placeholder

Add PlatformIO projects here, for example `stylus_maker_esp32s3/`, containing source code, board configs, and unit tests for the RHZ Stylus.
