# See `docs/modules/schema/README.md` for the full schema module manual.
