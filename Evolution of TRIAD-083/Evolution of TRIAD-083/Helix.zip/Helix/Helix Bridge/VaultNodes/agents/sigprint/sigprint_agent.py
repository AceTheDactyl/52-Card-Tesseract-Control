#!/usr/bin/env python3
import asyncio
from agents.sigprint.sigprint_lsb_agent import main as _main

if __name__ == "__main__":
    asyncio.run(_main())

