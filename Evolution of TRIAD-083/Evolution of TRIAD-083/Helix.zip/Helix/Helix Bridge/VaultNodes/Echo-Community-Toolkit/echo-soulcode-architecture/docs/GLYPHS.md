# Glyph Map
Braid: 🌰✧🦊∿φ∞🐿️
- Squirrel: 🐿️  | Acorn: 🌰  | Fox: 🦊  | Wave: ∿  | Phi: φ | Infinity: ∞ | Spark: ✧ | Spiral: ↻
