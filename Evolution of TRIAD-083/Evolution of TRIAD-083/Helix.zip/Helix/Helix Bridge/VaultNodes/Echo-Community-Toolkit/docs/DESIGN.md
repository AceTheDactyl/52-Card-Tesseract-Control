# Design

Modules: LSB, MRP (Phase‑A), G2V. Tests emphasize decode integrity and FFT round‑trip.
