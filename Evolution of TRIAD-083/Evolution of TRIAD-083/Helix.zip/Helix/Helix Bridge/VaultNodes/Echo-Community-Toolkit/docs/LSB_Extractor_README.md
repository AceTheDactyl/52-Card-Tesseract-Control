# LSB Extractor

Usage: python -m src.lsb_extractor (library API shown in demo.py).
