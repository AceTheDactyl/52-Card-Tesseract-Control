# MRP Overview

Phase‑A multiplexing across RGB, header format, and adapter notes.
