# Tink → Glyph Mapping

"I‑Glyph" → filled square; "Octave Cycle Drive" → horizontal bar.
