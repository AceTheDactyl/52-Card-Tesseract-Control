import React from 'react'
import LambdaStateViewer from './LambdaStateViewer'

export default function App() {
  return <LambdaStateViewer />
}
