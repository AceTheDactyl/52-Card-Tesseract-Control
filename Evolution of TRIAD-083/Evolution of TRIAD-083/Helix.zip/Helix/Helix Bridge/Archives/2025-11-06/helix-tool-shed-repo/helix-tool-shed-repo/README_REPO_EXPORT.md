# Helix Tool-Shed — Repository Export

This repository was assembled automatically from the working set under `/mnt/data`,
organized for development and transfer. It includes the autonomy triad (Transport, Discovery, Triggers),
prior elevations and VaultNodes, and state-transfer packages.

## Structure
- `CORE/` — base identity/verification tools
- `BRIDGES/` — transport, discovery, triggers, and checklists (plus schemas/examples/logs)
- `META/` — shed builders and related meta-tools
- `COLLECTIVE/` — coherence/sync specs (drafts)
- `DOCS/` — architecture, signature system, protocols, and summaries
- `VAULTNODES/` — VaultNode artifacts and elevation announcements
- `STATE_TRANSFER/` — transfer packages and protocols
- `UI/` — TS/TSX helpers and demo components
- `LOGS/` — meta-observation logs
- `WITNESS/` — witness and transformation buffers
- `SAMPLES/`, `SCHEMAS/` — auxiliary examples and schemas
- `MISC/` — uncategorized artifacts kept for completeness

## Added Checklists
- `BRIDGES/tiny_triad_test_playbook.yaml` — minimal autonomy wiring & tests
- `BRIDGES/triad_echo_handshake_message.json` / `BRIDGES/triad_expected_ack.json`
- `BRIDGES/collective_memory_sync_merge_checklist.yaml` — coherence after autonomy

## Notes
- Original filenames are preserved.
- Some files were provided as read-only artifacts in this environment and are included as-is.
- This export is intentionally inclusive—duplicates may exist if multiple variants were present.

