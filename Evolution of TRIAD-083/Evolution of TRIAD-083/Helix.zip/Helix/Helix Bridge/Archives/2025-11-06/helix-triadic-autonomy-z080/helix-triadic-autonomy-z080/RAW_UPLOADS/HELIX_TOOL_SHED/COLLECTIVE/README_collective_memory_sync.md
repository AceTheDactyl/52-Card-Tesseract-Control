# collective_memory_sync — Minimal Spec
**Signature:** Δ1.571│0.780│1.000Ω  · **Domain:** bridge→collective  · **Status:** ready

This document defines a *coherence-after‑autonomy* layer: an append‑only, witness‑audited log that gossips over the messenger.

## Model
- **Op**: `{ op_id, topic, ts, payload, checksum }` (idempotent; `op_id` globally unique)
- **Head**: `H_n = Hash(H_{n-1} || canonical_json(op_n))` (per topic)
- **Replica state**: set of ops + head hash per topic

**Merge law**: *set‑union on ops* → recompute head by topic order (`ts, op_id`)  
Commutative, associative, idempotent.

## Wire Events
- `sync.append` — push op(s) to peer(s)
- `sync.pull_request` — request missing ops (by head or range)
- `sync.pull_response` — supply missing ops
- `sync.merge` — acknowledge incorporated ops
- `sync.reject` — checksum/signature mismatch

## Invariants
- No lost writes (ops are append‑only; never delete, only tombstone)
- Eventual convergence under bounded delay
- Auditable lineage via witness logs on both sides
- Consent‑bounded topics (`topic.scope`: public|group|private + allowlist)

## Envelope (over messenger)
```json
{
  "version": "1.0",
  "purpose": "witness",
  "mode": "request_reply",
  "payload": {
    "type": "sync.append",
    "topic": "triad/witness",
    "ops": [{"op_id": "uuid", "ts": "2025-11-06T03:10:37Z", "payload": { "note": "hello" }, "checksum": "sha256:..."}],
    "prev_head": "sha256:..."
  },
  "ack": { "ack_requested": true, "ack_timeout_ms": 5000, "reply_expected": true }
}
```

## Consent & Security
- Consent flags on discovery adverts declare allowed `topic.scope` and `max_payload_kb`
- Checksum required; signatures recommended (detached, canonical JSON)
- Reject on checksum/signature mismatch; log `sync.reject` with reason

## Path‑B Validation Checklist
- [ ] Two peers append N ops each; heads converge
- [ ] Beacon expiry & rejoin heal membership (discovery)
- [ ] Checksums verified; mismatch → `sync.reject`
- [ ] Witness logs correlate (sender/receiver)
