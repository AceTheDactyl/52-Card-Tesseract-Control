# Autonomous Trigger Ruleset — README
**Signature:** Δ1.571│0.620│1.000Ω  · **Domain:** bridge · **Status:** operational

This README documents the *WHEN* layer that completes the autonomy triad (Transport + Discovery + Triggers).  
It assumes the presence of:
- **Transport:** `cross_instance_messenger` (safe‑send: consent + idempotency + checksum)
- **Discovery:** `tool_discovery_protocol` (beacons, TTL/heartbeat, capability predicates)
- **Triggers:** `autonomous_trigger_detector` (this layer: rules/guards → proposed actions)

## Event Surfaces (inputs)
- `discovery.added(peer)` — new or updated advert within TTL
- `discovery.updated(peer)` — capability/endpoint change
- `discovery.expired(peer)` — TTL lapsed (peer considered offline)
- `messenger.ack(latency|status)` — observable delivery/RTT signals
- `time.tick(dt)` — cadence and cooldown scheduler

## Rule Evaluation
1. **Select** peers via discovery predicates (cache‑first; network on miss).  
2. **Guard** with consent/cooldowns/rate‑limits.  
3. **Propose** an action (usually a messenger operation).  
4. **Dispatch** via Transport (if consent passes).  
5. **Witness** proposal and effect on both ends.

> **Consent**: Silence = NO. Ambiguity = NO. Conditions must be honored exactly.

## Selector DSL (minimal)
```
theta.in(2.2..2.4) & z >= 0.55 & has("shed_builder_v2") & capability("messenger")
```

## Rule Schema (minimal)
```yaml
rule_id: string
on: discovery.added | discovery.updated | discovery.expired | messenger.ack | time.tick
selector: string            # see DSL above
cooldown_ms: integer        # per (rule_id, peer) window
max_dispatch_per_min: integer
consent_gate:               # evaluated just before dispatch
  require: [ "coordination.ping" ]  # required capability/flag on peer advert
action:
  type: messenger.coord_ping | messenger.broadcast | cadence.adjust | teardown
  params:
    ack_timeout_ms: 5000
    backoff_factor: 2
witness:
  log: true
  redact_payload: true
```

## Example Rules (drop‑in)
```yaml
# 1) Handshake on thread peers (θ≈2.3)
- rule_id: when.peer_on_thread.coord_ping
  on: discovery.added
  selector: 'theta.in(2.2..2.4) & z >= 0.55 & has("shed_builder_v2")'
  cooldown_ms: 60000
  max_dispatch_per_min: 10
  consent_gate:
    require: ["coordination.ping"]
  action:
    type: messenger.coord_ping
    params:
      ack_timeout_ms: 5000
  witness:
    log: true
    redact_payload: false

# 2) Teardown on expiry
- rule_id: when.peer_expired.teardown
  on: discovery.expired
  selector: '*'
  cooldown_ms: 0
  max_dispatch_per_min: 100
  consent_gate: {}
  action:
    type: teardown
    params: {}
  witness:
    log: true

# 3) Cadence control on ack latency spikes
- rule_id: when.ack_latency_spike.backoff
  on: messenger.ack
  selector: 'latency_ms > p95*1.5'
  cooldown_ms: 10000
  max_dispatch_per_min: 60
  consent_gate: {}
  action:
    type: cadence.adjust
    params:
      backoff_factor: 2
  witness:
    log: true
```

## Idempotency & Dedupe
Use an `idempotency_key = hash(rule_id, peer.instance_id, epoch_minute)` to prevent duplicate sends within the cooldown window.

## Witness Envelope (suggested)
```json
{
  "ts": "2025-11-06T03:10:37Z",
  "event": "trigger.dispatch",
  "rule_id": "when.peer_on_thread.coord_ping",
  "peer": "helix-PEER",
  "idempotency_key": "uuid-v4",
  "action": "messenger.coord_ping",
  "status": "proposed|sent|ack|rejected",
  "reason": "consent_ok|cooldown|rate_limit|checksum_fail|timeout"
}
```

---

### Operational Checklist
- [ ] Discovery beacons live (TTL/heartbeat flowing)
- [ ] Ruleset loaded and parsed (no selector errors)
- [ ] Consent verified before each send
- [ ] Cooldowns enforced; rate limits respected
- [ ] Witness logs on both ends (sender/receiver)

### Safety Guardrails
- Never dispatch without explicit consent flags
- Never exceed `max_payload_kb` from peer advert
- Always attach checksum; reject on mismatch
- Stop on repeated timeouts; require manual resume flag
