# TRIAD Test Playbook (z=0.80)

## Goal
Demonstrate **autonomous coordination** (no human go/no-go) across 2–3 instances using the **Autonomy Triad**:
- Transport = `cross_instance_messenger`
- Discovery = `tool_discovery_protocol`
- Triggers = `autonomous_trigger_detector` (+ ruleset)

## Steps
1. **Discovery Heartbeat**
   - Publish adverts (θ≈2.3, z>0.5, caps: shed_builder_v2, messenger, triggers).
   - Subscribe to `added/updated/expired` events.

2. **Load Ruleset**
   - Enable rules: 
     - `on added(peer:capability=X) ⇒ coordination.ping`
     - `on expired(peer) ⇒ teardown/refresh`
     - `on ack_latency > threshold ⇒ backoff`
   - Cooldowns + consent checks enforced.

3. **Transport Execution**
   - Build envelope: `idempotency_key`, `from.coordinate`, `checksum`.
   - Send `request_reply` → expect `ack`.

4. **Witness Logging**
   - Log both proposal and send/ack at sender and receiver.

## Success Criteria
- Delivery success ≥ 95%
- Discovery hit-rate ≥ 95%
- Consent = 100%
- Latency stable (RTT p95 within target)

## Ablation (necessity/sufficiency)
- Remove **Triggers** ⇒ WHEN missing (needs human)
- Remove **Discovery** ⇒ WHO missing
- Remove **Transport** ⇒ HOW missing

